package com.pard.firstSeminar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSeminarApplicationTests {

	@Test
	void contextLoads() {
	}

}
