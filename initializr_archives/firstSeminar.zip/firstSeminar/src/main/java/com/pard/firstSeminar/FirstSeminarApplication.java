package com.pard.firstSeminar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSeminarApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSeminarApplication.class, args);
	}

}
